These are config files, background and arch installation guide.

To unzip folder just use:
   unzip


needed packages for this to work:
    pacman -S hyprland hyprpaper ly waybar nemo wofi konsole slurp grim

MOVE THE WAYBAR FOLDER INTO:
    /etc/xdg/waybar  
